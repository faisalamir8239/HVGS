# Holy Vision Global School — Babuan

A responsive school landing-page demo prepared by SoftX Solutions.

## GitHub Pages
1. Create a new GitHub repository, for example `holy-vision-global-school`.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/root`, then save.
6. GitHub will provide the public Pages URL.

## Before final launch
Replace the demo image and placeholder school contact details with the school's verified logo, photographs, address, phone, email and social links.
